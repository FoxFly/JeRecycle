package dbClass;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class connexionBDD
{
	public Statement connexionOuverte;
	
	public connexionBDD()
	{
	
		String pilote = "com.mysql.jdbc.Driver";
		try
		{
			Class.forName(pilote);
			System.out.print("Configuration en cours ..\n");
			Connection connexion = DriverManager.getConnection("jdbc:mysql://localhost/db_jerecycle","root","");
			System.out.print("Connexion en cours ..\n");
			connexionOuverte = connexion.createStatement();
		}
		catch (Exception e)
		{	
			System.out.println("echec pilote : "+e);
		}
	}
	
	public boolean tryLogin(String mail, String pwd)
	{
		ResultSet resultat;
		String pwdMail ="";
		boolean isConnected = false;
		try 
		{
			resultat = connexionOuverte.executeQuery("SELECT * FROM `db_jerecycle`.`user`");
			String mailFetched="";
			while(resultat.next())
			{	
				mailFetched = resultat.getString("mailUser");
				//System.out.println("N� ID_USER: "+resultat.getInt("IdUser"));
				//System.out.println("Mail : "+mailFetched);
				
				if(mailFetched.equals(mail))
				{
					System.out.println("Existe dans la base ! \n");
					pwdMail=resultat.getString("pwdUser");
					break;
				}
			}
			
			if(pwdMail != "")
			{
				System.out.println("Test du mot de passe ..\n");
				String reqConnexion = "SELECT * FROM `db_jerecycle`.`user` WHERE mailUser='"+mail+"' AND pwdUser=MD5('"+pwd+"');";
				System.out.println(reqConnexion);
				resultat = connexionOuverte.executeQuery(reqConnexion);
				isConnected=true;
				//ifSystem.out.println("Connect� !");
			}
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return isConnected;
	}
	
	
	public String getGroup(String mail)
	{
		ResultSet resultat;
		String group="";
		int idGroupUser=0;
		try 
		{
			resultat = connexionOuverte.executeQuery("SELECT * FROM `db_jerecycle`.`user` WHERE mailUser='"+mail+"'");

			while(resultat.next())
			{	
				idGroupUser = resultat.getInt("refIdGroup");
				System.out.println("---------------------------");
				System.out.println("ID group : "+idGroupUser);
			}
			
			if(idGroupUser>0)
			{
				resultat = connexionOuverte.executeQuery("SELECT * FROM `db_jerecycle`.`group` WHERE idGroup="+idGroupUser+";");
				while(resultat.next())
				{	
					group = resultat.getString("libGroup");
					System.out.println("---------------------------");
					System.out.println("Nom du group : "+group);
				}
			}
		} 
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return group;
	}
	
	public ArrayList<String> announcementList()
	{
		ArrayList<String> listAnn = new ArrayList<String>();
		ResultSet resultat;
		try 
		{
			resultat = connexionOuverte.executeQuery("SELECT * FROM `db_jerecycle`.`annoucement`");

			while(resultat.next())
			{	
				
			}			
		}
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return listAnn;
	}
	
	public ArrayList<String> brandList()
	{
		ArrayList<String> brandList = new ArrayList<String>();
		ResultSet resultat;
		try 
		{
			resultat = connexionOuverte.executeQuery("SELECT * FROM `db_jerecycle`.`brand`");

			while(resultat.next())
			{	
				brandList.add(resultat.getString("libBrand"));
			}			
		}
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Liste des marques :\n");
		for(int i=0; i< brandList.size();i++)
		{
			System.out.println(brandList.get(i).toString());
		}
		//System.out.println("Tableau retourn�");
		return brandList;
	}
	
	public ArrayList<String> modelList()
	{
		ArrayList<String> modelList = new ArrayList<String>();
		ResultSet resultat;
		try 
		{
			resultat = connexionOuverte.executeQuery("SELECT * FROM `db_jerecycle`.`model`");

			while(resultat.next())
			{	
				modelList.add(resultat.getString("libModel"));
			}			
		}
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Liste des mod�les :\n");
		for(int i=0; i< modelList.size();i++)
		{
			System.out.println(modelList.get(i).toString());
		}
		//System.out.println("Tableau retourn�");
		return modelList;
	}
	
	public ArrayList<String> categoryList()
	{
		ArrayList<String> categoryList = new ArrayList<String>();
		ResultSet resultat;
		try 
		{
			resultat = connexionOuverte.executeQuery("SELECT * FROM `db_jerecycle`.`category`");

			while(resultat.next())
			{	
				categoryList.add(resultat.getString("libCategory"));
			}			
		}
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Liste des categories :\n");
		for(int i=0; i< categoryList.size();i++)
		{
			System.out.println(categoryList.get(i).toString());
		}
		//System.out.println("Tableau retourn�");
		return categoryList;
	}
	
	public void addAnnoucement(String device, String brand, String model, String color, String state, int price, String comment, String user)
	{
		ResultSet resultat;
		int idCat=0, idBrand=0, idModel=0, idUser=0;
		
		try 
		{

			resultat = connexionOuverte.executeQuery("SELECT * FROM `db_jerecycle`.`category` WHERE libCategory ='"+device+"'");
			while(resultat.next())
			{	
				idCat = resultat.getInt("idCategory");
			}

			resultat = connexionOuverte.executeQuery("SELECT * FROM `db_jerecycle`.`Model` WHERE libModel ='"+model+"'");
			while(resultat.next())
			{	
				idModel = resultat.getInt("idModel");
			}

			resultat = connexionOuverte.executeQuery("SELECT * FROM `db_jerecycle`.`brand` WHERE libBrand='"+brand+"'");
			while(resultat.next())
			{	
				idBrand = resultat.getInt("idBrand");
			}

			resultat = connexionOuverte.executeQuery("SELECT * FROM `db_jerecycle`.`user` WHERE mailUser='"+user+"'");
			while(resultat.next())
			{	
				idUser = resultat.getInt("idUser");
				//idUser=1;
			}
			
			
			//System.out.println(idBrand+" "+idModel+" "+idCat);
			String reqInsertProd="INSERT INTO `db_jerecycle`.`product`(idProduct,stateProduct,colorProduct,refIdModel,refIdUser) VALUES (null,'"+state+"','"+color+"',"+idModel+",'1')";
			System.out.println(reqInsertProd);
			connexionOuverte.executeUpdate(reqInsertProd);
			
			
			int maxProduct=0;
			resultat = connexionOuverte.executeQuery("SELECT MAX(idProduct) FROM `db_jerecycle`.`product`");
			while(resultat.next())
			{	
				maxProduct = resultat.getInt("MAX(idProduct)");
			}
			String reqInsertAnn="INSERT INTO `db_jerecycle`.`announcement`(idAnnouncement,priceAnnoucement,refIdProduct,statutAnnoucement,commentAnnoucement) VALUES (null,"+price+","+maxProduct+",'1','"+comment+"');";
			System.out.println(reqInsertAnn);
			connexionOuverte.executeUpdate(reqInsertAnn);
			
			
			System.out.println("Ajout effectu� !");
		}
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public ArrayList<String> annoucementList()
	{
		ArrayList<String> listAnn = new ArrayList<String>();
		
		ResultSet resultat;
		try 
		{
			String reqListAnn ="SELECT libModel, colorProduct, addressUser, stateProduct, priceAnnoucement " +
					"FROM announcement as an, product as prod, user as us, model as mo "+
"WHERE an.refIdProduct = prod.idProduct "+
"AND prod.refIdUser = us.idUser "+
"AND prod.refIdModel = mo.idModel";
			resultat = connexionOuverte.executeQuery(reqListAnn);

			while(resultat.next())
			{	
				listAnn.add(resultat.getString("libModel")+";"+resultat.getString("colorProduct")+";"+resultat.getString("addressUser")+";"+resultat.getString("stateProduct")+";"+resultat.getString("priceAnnoucement"));
			}
			//System.out.println("TESTTTTT :"+listAnn.get(1));
		}
		catch (SQLException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return listAnn;
	}
}


package servlet;
import dbClass.connexionBDD;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.annotation.WebServlet;

/**
 * Servlet implementation class ServletConnection
 */
@WebServlet("/ServletDepotAnnonce")
public class ServletDepotAnnonce extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public ServletDepotAnnonce() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("toto");
		connexionBDD connexion = new connexionBDD();

		String deviceType = request.getParameter("device");
		String deviceBrand = request.getParameter("brand");
		String deviceModel = request.getParameter("model");
		String deviceColor = request.getParameter("color");
		String deviceStatus = request.getParameter("state");
		int devicePrice = Integer.parseInt(request.getParameter("price"));
		String deviceComment = request.getParameter("comment");
		HttpSession session = request.getSession(true);
		String login = (String)session.getAttribute("login");
		connexion.addAnnoucement(deviceType,deviceBrand,deviceModel,deviceColor,deviceStatus,devicePrice,deviceComment,login);
		
		RequestDispatcher reqDispatcher = getServletConfig().getServletContext().getRequestDispatcher("/page/annonce");
		reqDispatcher.forward(request, response);
		
	}
}

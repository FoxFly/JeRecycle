package org.essilab.module.user.model;

public class User {
	public String login;
	public String password;
	Long id;
	boolean active = true;
	
	public User(String login, String password, Long id) {
		super();
		this.login = login;
		this.password = password;
		this.id = id;
	}

	public User(String login, String password) {
		super();
		this.login = login;
		this.password = password;
	}
}

package servlet;

import java.io.IOException;
import java.util.ArrayList;
import dbClass.connexionBDD;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletAjoutAnnonce
 */
@WebServlet("/ServletLoadList")
public class ServletLoadList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletLoadList() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		ArrayList<String> listBrand = new ArrayList<String>();
		ArrayList<String> listModel = new ArrayList<String>();
		ArrayList<String> listCateg = new ArrayList<String>();
		connexionBDD connexion = new connexionBDD();
		listBrand=connexion.brandList();
		listModel = connexion.modelList();
		listCateg = connexion.categoryList();
		System.out.println("J'ai mes listes \n");
		request.setAttribute("listBrand", listBrand);
		request.setAttribute("listModel", listModel);
		request.setAttribute("listCategory", listCateg);
		
		//Redirection vers les jsp
		RequestDispatcher reqDispatcher = getServletConfig().getServletContext().getRequestDispatcher("/page/deposeruneannonce.jsp");
	    reqDispatcher.forward(request,response);
	
	}

}

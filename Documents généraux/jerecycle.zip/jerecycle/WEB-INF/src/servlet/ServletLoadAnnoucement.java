package servlet;
import dbClass.connexionBDD;
import java.io.IOException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletConnection
 */
@WebServlet("/ServletLoadAnnoucement")
public class ServletLoadAnnoucement extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public ServletLoadAnnoucement() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		ArrayList<String> annList = new ArrayList<String>();
		connexionBDD connexion = new connexionBDD();
		annList=connexion.annoucementList();
		request.setAttribute("listAnnoucement", annList);
		//Redirection vers les jsp
		RequestDispatcher reqDispatcher = getServletConfig().getServletContext().getRequestDispatcher("/page/achat.jsp");
	    reqDispatcher.forward(request,response);
	
	}
}
